Programme C++ qui affiche "Bienvenue tout le monde !"
